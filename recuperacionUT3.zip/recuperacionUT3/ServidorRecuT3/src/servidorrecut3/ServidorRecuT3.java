package servidorrecut3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class ServidorRecuT3 {
    public static void main(String[] args) {
        int puerto = 12345;

        try (ServerSocket servidor = new ServerSocket(puerto)) {
            System.out.println("Servidor iniciado en el puerto " + puerto + ".");

            while (true) {
                try (Socket cliente = servidor.accept();
                     BufferedReader entrada = new BufferedReader(new InputStreamReader(cliente.getInputStream()));
                     PrintWriter salida = new PrintWriter(cliente.getOutputStream(), true)) {

                    System.out.println("Cliente conectado desde " + cliente.getInetAddress());

                    String palabra;
                    while ((palabra = entrada.readLine()) != null) {
                        if (palabra.equals("fin")) {
                            System.out.println("Cliente desconectado.");
                            break;
                        }

                        String respuesta = procesarPalabra(palabra);
                        salida.println(respuesta);
                        System.out.println("Envío respuesta al cliente: " + respuesta);
                    }
                } catch (IOException e) {
                    System.err.println("Error al procesar al cliente: " + e.getMessage());
                }
            }
        } catch (IOException ex) {
            System.err.println("Error al iniciar el servidor: " + ex.getMessage());
        }
    }

    private static String procesarPalabra(String palabra) {
        boolean Palindromo = Palindromo(palabra);

        if (Palindromo) {
            return palabra.toUpperCase() + " es un palíndromo.";
        } else {
            return palabra.toUpperCase() + " no es un palíndromo.";
        }
    }

    private static boolean Palindromo(String palabra) {
        palabra = palabra.toLowerCase();
        int inicio = 0;
        int fin = palabra.length() - 1;

        while (inicio < fin) {
            if (palabra.charAt(inicio) != palabra.charAt(fin)) {
                return false;
            }
            inicio++;
            fin--;
        }
        return true;
    }
}
