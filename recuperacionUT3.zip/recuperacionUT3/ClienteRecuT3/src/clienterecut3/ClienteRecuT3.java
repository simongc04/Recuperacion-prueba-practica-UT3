package clienterecut3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class ClienteRecuT3 {
    public static void main(String[] args) {
        String host = "localhost";
        int puerto = 12345;

        try (Socket socket = new Socket(host, puerto);
             PrintWriter salida = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader entrada = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             Scanner scanner = new Scanner(System.in)) {

            System.out.println("Conectado al servidor localhost en el puerto " + puerto + ".");
            System.out.println("Cliente para comprobación de palíndromos.");

            String palabra;

            while (true) {
                System.out.print("\nIntroduzca palabra: ");
                palabra = scanner.nextLine();  
                System.out.println("Envío palabra al servidor: " + palabra);

                salida.println(palabra);

                if (palabra.equals("fin")) {
                    break;
                }

                String respuesta = entrada.readLine();
                System.out.println("Respuesta del servidor: " + respuesta);
            }
        } catch (IOException e) {
            System.err.println("Error de conexión: " + e.getMessage());
        }
    }
}
